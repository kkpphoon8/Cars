# Detect_WLD > 2024-02-25 7:47pm
https://universe.roboflow.com/detections-yvpev/detect_wld

Provided by a Roboflow user
License: CC BY 4.0

